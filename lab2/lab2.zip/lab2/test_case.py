import search_algorithm as sa
import path_planning as pp
import numpy as np
import matplotlib.pyplot as plt
import copy

# Generate Map and get start & goal
map, info = pp.generateMap2d_obstacle([70, 70])
start = sa.Cell(np.where(map == -2))
goal = sa.Cell(np.where(map == -3))

# Generate different paths
dfs_path = sa.search(map, start, goal, "DFS")
bfs_path = sa.search(map, start, goal, "BFS")
random_path = sa.search(map, start, goal, "RANDOM")
greedy_path = sa.search(map, start, goal, "GREEDY")
astar_path_manhattan = sa.search(map, start, goal, "ASTAR_MAN")
astar_path_euclidean = sa.search(map, start, goal, "ASTAR_EUCLID")

# Maps
dfs_map = copy.deepcopy(map)
bfs_map = copy.deepcopy(map)
random_map = copy.deepcopy(map)
greedy_map = copy.deepcopy(map)
astar_man_map = copy.deepcopy(map)
astar_euclid_map = copy.deepcopy(map)

# Insert path to corresponding map
for cell in dfs_path:
    x = int(cell.position[0])
    y = int(cell.position[1])
    dfs_map[x][y] = -4
for cell in random_path:
    x = int(cell.position[0])
    y = int(cell.position[1])
    random_map[x][y] = -4
for cell in bfs_path:
    x = int(cell.position[0])
    y = int(cell.position[1])
    bfs_map[x][y] = -4
for cell in greedy_path:
    x = int(cell.position[0])
    y = int(cell.position[1])
    greedy_map[x][y] = -4
for cell in astar_path_euclidean:
    x = int(cell.position[0])
    y = int(cell.position[1])
    astar_euclid_map[x][y] = -4
for cell in astar_path_manhattan:
    x = int(cell.position[0])
    y = int(cell.position[1])
    astar_man_map[x][y] = -4

# Print some tasty stats
print "############# STATS ############"
print "DFS: ", len(dfs_path), "steps"
print "BFS: ", len(bfs_path), "steps"
print "RANDOM: ", len(random_path), "steps"
print "GREEDY: ", len(greedy_path), "steps"
print "ASTAR MANHATTAN: ", len(astar_path_manhattan), "steps"
print "ASTAR EUCLIDEAN: ", len(astar_path_euclidean), "steps"

# Plot
fig = plt.figure()
ax = fig.add_subplot(2,3,1)
ax.set_title("DFS")
ax.imshow(dfs_map)
ax = fig.add_subplot(2,3,2)
ax.set_title("BFS")
ax.imshow(bfs_map)
ax = fig.add_subplot(2,3,3)
ax.set_title("RANDOM")
ax.imshow(random_map)
ax = fig.add_subplot(2,3,4)
ax.set_title("GREEDY")
ax.imshow(greedy_map)
ax = fig.add_subplot(2,3,5)
ax.set_title("ASTAR MANHATTAN")
ax.imshow(astar_man_map)
ax = fig.add_subplot(2,3,6)
ax.set_title("ASTAR EUCLIDEAN")
ax.imshow(astar_euclid_map)
plt.show()

