import math
import heapq
import random


# Priority Queue based on heapq
class PriorityQueue:
    def __init__(self):
        self.elements = []

    def isEmpty(self):
        return len(self.elements) == 0

    def add(self, item, priority):
        heapq.heappush(self.elements,(priority,item))

    def remove(self):
        return heapq.heappop(self.elements)[1]


# Search
def search(map, start, goal, type):
    frontier = PriorityQueue()
    frontier.add(start, 0)
    size_x = map.shape[0]
    size_y = map.shape[1]

    # Store information about visited cells, add information about obstacles
    closed = [[0 for row in range(size_x)] for col in range(size_y)]
    for x in range(size_x):
        for y in range(size_y):
            if map[x][y] == -1:
                closed[x][y] = -1

    # path taken, it is up to each cell to store this information as parent
    path = []

    # init. starting node
    start.parent = None

    while not frontier.isEmpty():
        current_cell = frontier.remove()

        # check if the goal is reached
        if current_cell == goal:
            while current_cell.parent != None:
                path.append(current_cell)
                current_cell = current_cell.parent
            break

        # for each neighbour of the current cell
        for next in get_neighbors(current_cell, goal, map, closed, type):

            # Based on type, add neighbor to frontier with respective priority
            if type == "DFS":
                frontier.add(next, -next.g)
            if type == "BFS":
                frontier.add(next, 0)
            if type == "RANDOM":
                frontier.add(next, random.randint(0,100))
            if type == "ASTAR_MAN" or type == "ASTAR_EUCLID":
                frontier.add(next, next.f)
            if type == "GREEDY":
                frontier.add(next, next.h)
    return path


# Returns a list of neighbors belonging to current_cell
def get_neighbors(current_cell, goal, map, closed, type):
    size_x = map.shape[0] - 1
    size_y = map.shape[1] - 1
    x = int(current_cell.position[0])
    y = int(current_cell.position[1])

    # Mark current cell as visited
    closed[x][y] = 1
    neighbors = []

    if x != 0:
        if closed[x-1][y] == 0:
            cell = Cell((x - 1, y))
            cell.parent = current_cell
            cell.g = cell.parent.g + 1
            if type == "ASTAR_MAN":
                cell.h = manhattan_distance(cell, goal)
            else:
                cell.h = euclidean_distance(cell, goal)
            cell.f = cell.g + cell.h
            neighbors.append(cell)
            closed[x-1][y] = 1
    if x != size_x:
        if closed[x+1][y] == 0:
            cell = Cell((x + 1, y))
            cell.parent = current_cell
            cell.g = cell.parent.g + 1
            if type == "ASTAR_MAN":
                cell.h = manhattan_distance(cell, goal)
            else:
                cell.h = euclidean_distance(cell, goal)
            cell.f = cell.g + cell.h
            neighbors.append(cell)
            closed[x+1][y] = 1
    if y != 0:
        if closed[x][y-1] == 0:
            cell = Cell((x, y - 1))
            cell.parent = current_cell
            cell.g = cell.parent.g + 1
            if type == "ASTAR_MAN":
                cell.h = manhattan_distance(cell, goal)
            else:
                cell.h = euclidean_distance(cell, goal)
            cell.f = cell.g + cell.h
            neighbors.append(cell)
            closed[x][y-1] = 1
    if y != size_y:
        if closed[x][y+1] == 0:
            cell = Cell((x, y + 1))
            cell.parent = current_cell
            cell.g = cell.parent.g + 1
            if type == "ASTAR_MAN":
                cell.h = manhattan_distance(cell, goal)
            else:
                cell.h = euclidean_distance(cell, goal)
            cell.f = cell.g + cell.h
            neighbors.append(cell)
            closed[x][y+1] = 1
    return neighbors


# Returns manhattan distance from start to goal
def manhattan_distance(start, goal):
    manhattan_distance = 2*(abs(int(goal.position[0]) - int(start.position[0])) + abs(int(goal.position[1]) - int(start.position[1])))
    return manhattan_distance


# Returns euclidean distance from start to goal
def euclidean_distance(start, goal):
    x_distance = abs(int(goal.position[0]) - int(start.position[0]))
    y_distance = abs(int(goal.position[1]) - int(start.position[1]))
    distance = math.sqrt(x_distance**2+y_distance**2)
    return distance


class Cell:

    # Structure for a cell in the map
    def __init__(self, position):
        self.position = position
        self.parent = None
        self.g = 0  # Distance from start
        self.h = 0  # Heuristic
        self.f = 0  # g+h

    def __eq__(self, other):
        if other is not None:
            if self.position[0] == other.position[0] and self.position[1] == other.position[1]:
                return True
            else:
                return False
        else:
            return False
